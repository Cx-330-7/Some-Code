package work.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface SortMapper {
    @Insert("insert into Bubble (Num) values (#{arr})")
    public int BubbleInsert(@Param("arr")int number);

    @Insert("insert into Shell (Num) values (#{arr})")
    public int ShellInsert(@Param("arr")int number);

    @Insert("insert into Quick (Num) values (#{arr})")
    public int QuickInsert(@Param("arr")int number);

    @Insert("insert into MyInsert (Num) values (#{arr})")
    public int InsetInsert(@Param("arr")int number);
}
