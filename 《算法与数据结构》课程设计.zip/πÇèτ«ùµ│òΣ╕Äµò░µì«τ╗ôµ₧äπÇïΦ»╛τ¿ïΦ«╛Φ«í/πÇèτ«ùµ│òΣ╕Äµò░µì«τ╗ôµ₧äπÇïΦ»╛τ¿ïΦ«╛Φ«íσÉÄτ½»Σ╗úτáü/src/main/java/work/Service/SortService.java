package work.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import work.mapper.SortMapper;



@Service
public class SortService {
    @Autowired
    SortMapper sortMapper;

    public int BubbleInsert(int number) {
        return sortMapper.BubbleInsert(number);
    }
    public int ShellInsert(int number){
        return sortMapper.ShellInsert(number);
    }
    public int QuickInsert(int number){
        return sortMapper.QuickInsert(number);
    }
    public int InsertInsert(int number){
        return sortMapper.InsetInsert(number);
    }
}
