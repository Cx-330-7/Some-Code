package work.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.springframework.web.bind.annotation.*;
import work.entity.People;

import java.util.HashMap;

@RestController
@RequestMapping("/api/idMag")
public class IdCardManagement {
    public static HashMap<String, People> hashMap = new HashMap();

    @CrossOrigin
    @RequestMapping("/insert")
    public JSONObject insert(@RequestParam("name") String name, @RequestParam("address") String address,
                             @RequestParam("phone") String phone, @RequestParam("id") String id) {
        JSONObject json = new JSONObject();
        int code;
        String msg;
        People people = new People(name, address, phone, id);
        if (hashMap.get(id) != null) {
            code = 999;
            msg = "您已在系统中";
        } else {
            hashMap.put(id, people);
            code = 200;
            msg = "插入成功";
        }
        json.put("code", code);
        json.put("msg", msg);
        return json;
    }

    @CrossOrigin
    @RequestMapping("/query")
    public JSONObject QueryPeople(@RequestParam("id") String id) {
        JSONObject json = new JSONObject();
        int code;
        String msg;
        People data = null;
        People people = hashMap.get(id);
        if (people == null) {
            code = 999;
            msg = "查无此人";
        } else {
            code = 200;
            msg = "查询成功";
            data = people;
        }
        json.put("code", code);
        json.put("msg", msg);
        json.put("data", data);
        return json;
    }

    @CrossOrigin
    @RequestMapping("/change")
    public JSONObject ChangePeople(@RequestParam("name") String name, @RequestParam("address") String address,
                                   @RequestParam("phone") String phone, @RequestParam("id") String id) {
        JSONObject json = new JSONObject();
        int code;
        String msg;
        if (hashMap.get(id) == null) {
            code = 999;
            msg = "您的尚未录入系统";
        } else {
            code = 200;
            People people = new People(name, address, phone, id);
            hashMap.put(id, people);
            msg = "修改成功";
        }
        json.put("code", code);
        json.put("msg", msg);
        return json;
    }

    @CrossOrigin
    @RequestMapping("/delete")
    public JSONObject DeletePeople(@RequestParam("id") String id) {
        JSONObject json = new JSONObject();
        int code;
        String msg;
        if (hashMap.get(id) == null) {
            code = 999;
            msg = "您的尚未录入系统";
        } else {
            code = 200;
            hashMap.remove(id);
            msg = "删除成功";
        }
        json.put("code", code);
        json.put("msg", msg);
        return json;
    }
}
