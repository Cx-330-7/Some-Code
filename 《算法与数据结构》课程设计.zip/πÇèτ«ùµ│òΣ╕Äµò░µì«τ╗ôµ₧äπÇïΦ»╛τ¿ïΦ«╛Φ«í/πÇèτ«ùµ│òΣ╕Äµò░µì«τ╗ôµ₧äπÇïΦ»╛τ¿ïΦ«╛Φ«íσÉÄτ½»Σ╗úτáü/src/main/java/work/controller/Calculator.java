package work.controller;

import com.alibaba.fastjson.JSONObject;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import java.util.ArrayList;
import java.util.EmptyStackException;
import java.util.List;
import java.util.Stack;

@RestController
public class Calculator {
    private static int ADD = 1;
    private static int SUB = 1;
    private static int MUL = 2;
    private static int DIV = 2;

    /**
     * @param expression 输入的中缀表达式，中缀表达式先转换为后缀
     * @return
     */
    @CrossOrigin
    @RequestMapping("/api/cal")
    public JSONObject Result(@RequestParam("expression") String expression) {
        JSONObject json = new JSONObject();
        int code;
        String msg;
        String data = null;
        try {
            List<String> InfixExpression = toInfixExpressionList(expression);
            List<String> SuffixExpression = parseSuffixExpressList(InfixExpression);
            System.out.println(expression);
            Stack stack = new Stack();
            for (int i = 0; i < SuffixExpression.size(); i++) {
                char chr = SuffixExpression.get(i).charAt(0);
                if (!Judge(chr)) {
                    stack.push(SuffixExpression.get(i));
                } else {
                    double num1 = Double.parseDouble(String.valueOf(stack.pop()));
                    double num2 = Double.parseDouble(String.valueOf(stack.pop()));
                    stack.push(Calculate(num1, num2, chr));
                }
            }
            data = String.valueOf(stack.pop());
            if (data == "Infinity") {
                code = 999;
                msg = "Math Error";
            } else if (!isNumeric(data)) {
                code = 500;
                msg = "请输入正确的算式";
            } else {
                code = 200;
                msg = "Success";
            }
        } catch (EmptyStackException e) {
            code = 500;
            msg = "请输入正确的算式";
        }

        json.put("code", code);
        json.put("msg", msg);
        json.put("data", data);
        return json;
    }

    /**
     * @param s 传入一个中缀表达式并用List储存
     * @return 例如 3*4+12--->[3,*,4,+,12]
     */
    public static List<String> toInfixExpressionList(String s) {
        List<String> ls = new ArrayList<>();
        int i = 0;
        String str;
        char c;

        do {
            if ((c = s.charAt(i)) < 48 || (c = s.charAt(i)) > 57) {
                /**
                 * Ascii-48为0，Ascii-57为9.
                 */
                ls.add("" + c);  //ls为String类型的链表，所以c前面要加个""。
                i++;
            } else {
                str = "";
                while (i < s.length() && ((c = s.charAt(i)) >= 48 && (c = s.charAt(i)) <= 57)) {
                    str += c;
                    i++;
                }
                ls.add(str);
            }
        } while (i < s.length());
        return ls;
    }

    /**
     * @param ls 由中缀表达式形成的List
     * @return
     */
    public static List<String> parseSuffixExpressList(List<String> ls) {
        Stack<String> stack = new Stack<>();
        List<String> list = new ArrayList<>();
        for (String item : ls) {
            if (isNumeric(item)) {
                list.add(item);
            } else if (item.equals("(")) {
                stack.push(item);
            } else if (item.equals(")")) {
                while (!stack.peek().equals("(")) {
                    list.add(stack.pop());
                }
                stack.pop();//将"("出栈
            } else {
                while (stack.size() != 0 && getValue(stack.peek()) >= getValue(item)) {
                    list.add(stack.pop());
                }
                stack.push(item);
            }
        }
        while (stack.size() != 0) {
            list.add(stack.pop());
        }
        return list;
    }

    static int getValue(String operation) {
        int result = 0;
        switch (operation) {
            case "+":
                result = ADD;
                break;
            case "-":
                result = SUB;
                break;
            case "*":
                result = MUL;
                break;
            case "/":
                result = DIV;
                break;
        }
        return result;
    }

    public static boolean isNumeric(String str) {
        for (int i = str.length(); --i >= 0; ) {
            int chr = str.charAt(i);
            if ((chr < 48 || chr > 57) && chr != 46) {
                return false;
            }
        }
        return true;
    }

    public static boolean Judge(char k) {
        return k == '+' || k == '-' || k == '*' || k == '/';
    }

    public static double Calculate(double num1, double num2, char ope) {
        double result = 0;
        switch (ope) {
            case '+':
                result = num1 + num2;
                break;
            case '-':
                result = num2 - num1;
                break;
            case '*':
                result = num1 * num2;
                break;
            case '/':
                result = num2 / num1;
                break;
        }
        return result;

    }


}
