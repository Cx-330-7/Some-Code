package work.controller;

import com.alibaba.fastjson.JSONObject;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import work.Service.SortService;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;

@RestController
@RequestMapping("/api/sort")
public class Sort {
    @Autowired
    SortService sortService;
    private static final int[] arr = new int[30000];

    @CrossOrigin
    @RequestMapping("/shell")
    public JSONObject ShellSort() {
        try {
            //建立输入流
            FileInputStream fip = new FileInputStream("/Users/zhengjunyuan/Desktop/随机数.xls");
            HSSFWorkbook wb = new HSSFWorkbook(fip);
            Sheet sheet = wb.getSheet("Sheet1");
            Row r = sheet.getRow(0);
            for (int i = 0; i <= 20000; i++) {
                Row row = sheet.getRow(i + 1);
                arr[i] = (int) row.getCell(0).getNumericCellValue();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        JSONObject json = new JSONObject();
        int code;
        String msg;
        long data;
        long startTime = System.currentTimeMillis();
        int n = arr.length;
        int gap = n/2;
        while(gap > 0){
            for(int j = gap; j < n; j++){
                int i=j;
                while(i >= gap && arr[i-gap] > arr[i]){
                    int temp = arr[i-gap]+arr[i];
                    arr[i-gap] = temp-arr[i-gap];
                    arr[i] = temp-arr[i-gap];
                    i -= gap;
                }
            }
            gap = gap/2;
        }

        long endTime = System.currentTimeMillis();
        long time = endTime - startTime;
        /*for (int i = 0; i < arr.length; i++) {
            sortService.ShellInsert(arr[i]);
        }*/
        code = 200;
        msg = "排序完成";
        data = time;
        json.put("code", code);
        json.put("msg", msg);
        json.put("data", data);
        return json;
    }

    @CrossOrigin
    @RequestMapping("/quick")
    public JSONObject QuickSort() {
        try {
            //建立输入流
            FileInputStream fip = new FileInputStream("/Users/zhengjunyuan/Desktop/随机数.xls");
            HSSFWorkbook wb = new HSSFWorkbook(fip);
            Sheet sheet = wb.getSheet("Sheet1");
            Row r = sheet.getRow(0);
            for (int i = 0; i <= 20000; i++) {
                Row row = sheet.getRow(i + 1);
                arr[i] = (int) row.getCell(0).getNumericCellValue();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        JSONObject json = new JSONObject();
        int code;
        String msg;
        long data;
        long startTime = System.currentTimeMillis();
        qsort(arr, 0, 20000);
        long endTime = System.currentTimeMillis();
        long time = endTime - startTime;
        /*for (int i = 0; i < arr.length; i++) {
            sortService.QuickInsert(arr[i]);
        }*/

        code = 200;
        msg = "排序成功";
        data = time;
        json.put("code", code);
        json.put("msg", msg);
        json.put("data", data);
        return json;
    }

    public static int[] qsort(int arr[], int start, int end) {
        int pivot = arr[start];
        int i = start;
        int j = end;
        while (i < j) {
            while ((i < j) && (arr[j] > pivot)) {
                j--;
            }
            while ((i < j) && (arr[i] < pivot)) {
                i++;
            }
            if ((arr[i] == arr[j]) && (i < j)) {
                i++;
            } else {
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        if (i - 1 > start) {
            arr = qsort(arr, start, i - 1);
        }
        if (j + 1 < end) {
            arr = qsort(arr, j + 1, end);
        }
        return (arr);
    }

    @CrossOrigin
    @RequestMapping("/insert")
    public JSONObject InsertSort() {
        try {
            //建立输入流
            FileInputStream fip = new FileInputStream("/Users/zhengjunyuan/Desktop/随机数.xls");
            HSSFWorkbook wb = new HSSFWorkbook(fip);
            Sheet sheet = wb.getSheet("Sheet1");
            Row r = sheet.getRow(0);
            for (int i = 0; i <= 20000; i++) {
                Row row = sheet.getRow(i + 1);
                arr[i] = (int) row.getCell(0).getNumericCellValue();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        JSONObject json = new JSONObject();
        int code;
        String msg;
        long data;
        long startTime = System.currentTimeMillis();
        for (int i = 1; i < arr.length; i++) {
            for (int j = i; j > 0; j--) {
                if (arr[j] < arr[j - 1]) {
                    int temp = arr[j - 1];
                    arr[j - 1] = arr[j];
                    arr[j] = temp;
                }
            }
        }

        long endTime = System.currentTimeMillis();
        long time = endTime - startTime;
        /*for (int i = 0; i < arr.length; i++) {
            sortService.InsertInsert(arr[i]);
        }*/
        code = 200;
        msg = "排序成功";
        data = time;
        json.put("code", code);
        json.put("msg", msg);
        json.put("data", data);
        return json;
    }

    @CrossOrigin
    @RequestMapping("/bubble")
    public JSONObject BubbleSort() throws IOException {
        try {
            //建立输入流
            FileInputStream fip = new FileInputStream("/Users/zhengjunyuan/Desktop/随机数.xls");
            HSSFWorkbook wb = new HSSFWorkbook(fip);
            Sheet sheet = wb.getSheet("Sheet1");
            Row r = sheet.getRow(0);
            for (int i = 0; i <= 20000; i++) {
                Row row = sheet.getRow(i + 1);
                arr[i] = (int) row.getCell(0).getNumericCellValue();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        JSONObject json = new JSONObject();
        int code;
        String msg;
        long data;
        int container;
        long startTime = System.currentTimeMillis();
        for (int i = 0; i < arr.length - 1; i++) {//第一层for循环控制所有数比较的次数
            for (int j = 0; j < arr.length - 1 - i; j++) {//第二次for循环控制，每次比较的次数，通过-1让下标长度最大达到数组的长度，通过-i，控制每次循环进行比较的个数
                if (arr[j] < arr[j + 1]) {
                    container = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = container;
                    //通过if语句，比较两个数的大小，如果前一个数没后一个数大，则交换它们的位置。通过一个空数据，来进行数的交换
                }
            }
        }
        long endTime = System.currentTimeMillis();
        long time = endTime - startTime;
        /*for (int i = 0; i < arr.length; i++) {
            sortService.BubbleInsert(arr[i]);
        }*/
        code = 200;
        msg = "排序成功";
        data = time;
        json.put("code", code);
        json.put("msg", msg);
        json.put("data", data);
        return json;
    }
}
