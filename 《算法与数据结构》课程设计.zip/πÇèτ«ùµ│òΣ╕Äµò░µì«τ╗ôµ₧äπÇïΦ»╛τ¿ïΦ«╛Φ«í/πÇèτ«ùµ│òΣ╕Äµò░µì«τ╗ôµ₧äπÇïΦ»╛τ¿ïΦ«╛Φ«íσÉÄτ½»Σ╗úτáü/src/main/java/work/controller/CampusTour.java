package work.controller;


import com.alibaba.fastjson.JSONObject;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import work.entity.EdgeWeightedDigraph;
import work.entity.LenAndRoad;
import work.entity.LensAndRoads;
import work.entity.Road;
import work.utils.DijkstraSP;

import java.util.Stack;

@RestController
@RequestMapping("/api/guide")
public class CampusTour {
    public static EdgeWeightedDigraph G;
    public static String[] intro = new String[13];

    @CrossOrigin
    @RequestMapping("/OneToAll")
    public JSONObject OneToAll(@RequestParam("point") int start) {
        int code;
        String msg;
        LensAndRoads data = null;
        String road;
        String[] roads = new String[13];
        JSONObject json = new JSONObject();

        if (start < 1 || start > 12) {
            code = 999;
            msg = "请输入正确的景点序号";
            json.put("code", code);
            json.put("msg", msg);
            json.put("data", data);
            return json;
        }
        DijkstraSP dijkstraSP = new DijkstraSP(G, start);
        double[] len = new double[13];
        for (int i = 1; i <= 12; i++) {
            if (i != start) {
                len[i] = dijkstraSP.distTo(i);
                Stack<Road> stack = dijkstraSP.pathTo(i);
                road = "";
                road = road + stack.peek().getStart() + "->" + stack.pop().getEnd();
                while (stack.size() > 1) {
                    road = road + "->" + stack.pop().getEnd();
                }
                if (stack.size() == 1) {
                    road = road + "->" + stack.pop().getEnd();
                }
                roads[i] = road;
            }
        }


        data = new LensAndRoads(len, roads);
        code = 200;
        msg = "查找成功";
        json.put("code", code);
        json.put("msg", msg);
        json.put("data", data);
        return json;
    }

    @CrossOrigin
    @RequestMapping("/OneToOne")
    public JSONObject OneToOne(@RequestParam("start") int start, @RequestParam("end") int end) {
        int code;
        String msg;
        JSONObject json = new JSONObject();
        LenAndRoad data = null;

        if (start < 1 || start > 12 || end < 1 || end > 12) {
            code = 999;
            msg = "请输入正确的景点序号";
            json.put("code", code);
            json.put("msg", msg);
            json.put("data", data);
            return json;
        }
        DijkstraSP dijkstraSP = new DijkstraSP(G, start);
        double len = dijkstraSP.distTo(end);
        Stack<Road> stack = dijkstraSP.pathTo(end);
        String road = "";
        road = road + stack.peek().getStart() + "->" + stack.pop().getEnd();
        while (stack.size() > 1) {
            road = road + "->" + stack.pop().getEnd();
        }

        if (stack.size() == 1) {
            road = road + "->" + stack.pop().getEnd();
        }

        data = new LenAndRoad(len, road);
        code = 200;
        msg = "查找成功";
        json.put("code", code);
        json.put("msg", msg);
        json.put("data", data);
        return json;
    }

    @CrossOrigin
    @RequestMapping("/intro")
    public JSONObject Intro(@RequestParam("num") int num) {
        int code;
        String msg;
        String data = null;
        JSONObject json = new JSONObject();


        data = intro[num];
        code = 200;
        msg = "查找成功！";
        json.put("code", code);
        json.put("msg", msg);
        json.put("data", data);
        return json;
    }

    static {
        Road r1 = new Road(1, 2, 3);
        Road r2 = new Road(1, 11, 4.2);
        Road r3 = new Road(2, 3, 3.2);
        Road r4 = new Road(2, 1, 4);
        Road r5 = new Road(3, 5, 1);
        Road r6 = new Road(4, 5, 2);
        Road r7 = new Road(4, 7, 6.8);
        Road r8 = new Road(5, 6, 7);
        Road r9 = new Road(5, 4, 4.3);
        Road r10 = new Road(6, 4, 2.2);
        Road r11 = new Road(6, 7, 2);
        Road r12 = new Road(7, 8, 6.7);
        Road r13 = new Road(8, 10, 8);
        Road r14 = new Road(8, 12, 9);
        Road r15 = new Road(9, 10, 2.4);
        Road r16 = new Road(10, 11, 5);
        Road r17 = new Road(10, 1, 1);
        Road r18 = new Road(11, 1, 2);
        Road r19 = new Road(11, 2, 6);
        Road r20 = new Road(11, 12, 3);
        Road r21 = new Road(11, 9, 3.5);
        Road r22 = new Road(12, 11, 1.2);
        Road r23 = new Road(12, 6, 3.3);
        Road r24 = new Road(12, 7, 3.6);
        G = new EdgeWeightedDigraph(13);
        G.addEdge(r1);
        G.addEdge(r2);
        G.addEdge(r3);
        G.addEdge(r4);
        G.addEdge(r5);
        G.addEdge(r6);
        G.addEdge(r7);
        G.addEdge(r8);
        G.addEdge(r9);
        G.addEdge(r10);
        G.addEdge(r11);
        G.addEdge(r12);
        G.addEdge(r13);
        G.addEdge(r14);
        G.addEdge(r15);
        G.addEdge(r16);
        G.addEdge(r17);
        G.addEdge(r18);
        G.addEdge(r19);
        G.addEdge(r20);
        G.addEdge(r21);
        G.addEdge(r22);
        G.addEdge(r23);
        G.addEdge(r24);

        intro[1] = "赛博北楼：中国计量大学信息工程学院的实验大楼，学院主要的实验室基本都聚集在这里，周老师经常在这上课。";
        intro[2] = "工程训练中心：工科金工实习基地与竞赛基地，周老师一般不在这。";
        intro[3] = "北操场：有看台的操场，运动会在这里举行，听说周老师在这里拿过奖。";
        intro[4] = "南操场：没有看台的操场，但是周老师在这个学期的运动会上拿了奖。";
        intro[5] = "嘉量大会堂：大型活动举办场所，周老师在吗。";
        intro[6] = "启明广场：百团大战、记者节等活动的举办场所，周老师散步的好场所。";
        intro[7] = "体育馆：打打球、上上课，周老师好像很喜欢乒乓。";
        intro[8] = "闻厅：小型会议举办场所，不知道周老师去不去那。";
        intro[9] = "方圆广场：图书馆对面的广场，周老师去上课应该会经过吧。";
        intro[10] = "图书馆：好多好多书，周老师经常去借书的吧。";
        intro[11] = "日月湖：好多好多鹅（不能恰）。";
        intro[12] = "情人坡：有情人吗？不知道～自己去看看吧。";
    }


}
