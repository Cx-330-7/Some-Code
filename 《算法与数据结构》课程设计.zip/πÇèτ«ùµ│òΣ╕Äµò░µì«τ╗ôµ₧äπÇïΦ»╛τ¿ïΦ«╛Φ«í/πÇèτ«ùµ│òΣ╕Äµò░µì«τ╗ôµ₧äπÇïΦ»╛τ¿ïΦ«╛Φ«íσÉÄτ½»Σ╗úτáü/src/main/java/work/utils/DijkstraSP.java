package work.utils;

import work.entity.EdgeWeightedDigraph;
import work.entity.Road;

import java.util.Queue;
import java.util.Stack;
import java.util.concurrent.LinkedBlockingQueue;

public class DijkstraSP {
    private Road[] edgeTo;//存放当前最短路径的最后一条边
    private double[] distTo;//存放当前顶点到指定顶点的当前的最短路径
    private IndexMinPriorityQueue<Double> pq;

    /**
     *
     * @param G 构造的有向加权图
     * @param s 规定的出发点
     */
    public DijkstraSP(EdgeWeightedDigraph G, int s) {
        this.edgeTo = new Road[G.getV()];//G.getV()返回的是G图的顶点数量
        this.distTo = new double[G.getV()];//distTo
        for (int i = 0; i < distTo.length; i++) {
            distTo[i] = Double.POSITIVE_INFINITY;
        }
        this.pq = new IndexMinPriorityQueue<Double>(G.getE());
        distTo[s] = 0.0;
        pq.insert(s, 0.0);
        while (!pq.isEmpty()) {
            relax(G, pq.delMin());
        }
    }

    private void relax(EdgeWeightedDigraph G, int v) {
        for (Road e : G.adj(v)) {
            int w = e.getEnd();
            if (distTo(w) > distTo(v) + e.getLength()) {
                distTo[w] = distTo(v) + e.getLength();
                edgeTo[w] = e;
                if (pq.contains(w)) {
                    pq.changeItem(w, distTo(w));
                } else {
                    pq.insert(w, distTo(w));
                }
            }
        }
    }

    public double distTo(int v) {
        return distTo[v];
    }

    public boolean hasPathTo(int v) {
        return distTo[v] < Double.POSITIVE_INFINITY;
    }

    //查询从起点s到顶点v的最短路径中所有的边
    public Stack<Road> pathTo(int v) {
        if (!hasPathTo(v)) {
            return null;
        }
        Stack<Road> edges = new Stack<>();
        Road e = null;
        while (true) {
            e = edgeTo[v];
            if (e == null) {
                break;
            }
            edges.push(e);
            v = e.getStart();
        }
        return edges;
    }
}
