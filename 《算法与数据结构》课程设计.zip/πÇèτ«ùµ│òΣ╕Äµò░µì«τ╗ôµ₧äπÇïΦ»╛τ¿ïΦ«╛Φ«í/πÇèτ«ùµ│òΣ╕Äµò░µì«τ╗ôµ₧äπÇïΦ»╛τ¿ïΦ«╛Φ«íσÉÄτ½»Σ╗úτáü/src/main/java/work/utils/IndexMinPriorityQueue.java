package work.utils;

/**
 * @author zhengjunyuan
 * Date 2022/1/9
 * @version 1.0
 * 索引优先队列
 * 以最小堆方式实现
 */
public class IndexMinPriorityQueue<T extends Comparable<T>> {
    /**
     * 存储元素的数组
     */
    private T[] items;
    /**
     * 保存 items 中元素的索引
     */
    private int[] pq;
    /**
     * pq数组 的逆序
     * pq中的值为qp的索引，pq的索引为qp的值
     */
    private int[] qp;
    /**
     * 元素的数量
     */
    private int n;

    /**
     * 构造器
     *
     * @param capacity
     */
    public IndexMinPriorityQueue(int capacity) {
        this.items = (T[]) new Comparable[capacity + 1];
        this.pq = new int[capacity + 1];
        this.qp = new int[capacity + 1];
        this.n = 0;

        // 初始化qp为-1
        for (int i = 0; i < qp.length; i++) {
            qp[i] = -1;
        }
    }

    /**
     * 元素数量
     *
     * @return
     */
    public int size() {
        return n;
    }

    /**
     * 队列是否为空
     *
     * @return
     */
    public boolean isEmpty() {
        return n < 1;
    }

    /**
     * 获取队列 pq 中索引i对应元素的值
     *
     * @param i
     * @return
     */
    public T get(int i) {
        if (i < 0 || i > pq.length) {
            return null;
        }
        return items[pq[i]];
    }

    /**
     * 判断堆中索引i处元素是否小于j处
     *
     * @param i
     * @param j
     * @return
     */
    private boolean less(int i, int j) {
        // 实际比较的是items中元素的值，而堆中存的是items元素的索引
        return items[pq[i]].compareTo(items[pq[j]]) < 0;
    }

    /**
     * 交换堆中索引i处与j处的值
     *
     * @param i
     * @param j
     */
    private void exch(int i, int j) {
        // i = 1; j = 3;
        // 交换前
        // pq[1] = 5   --->   qp[5] = 1
        // pq[3] = 7   --->   qp[7] = 3

        // 交换后
        // pq[1] = 7   --->   qp[7] = 1  =>  qp[pq[1]] = 1  =>  qp[pq[i]] = i
        // pq[3] = 5   --->   qp[5] = 3  =>  qp[pq[3]] = 3  =>  qp[pq[j]] = j

        // 交换pq
        int temp = pq[i];
        pq[i] = pq[j];
        pq[j] = temp;

        // 交换qp
        qp[pq[i]] = i;
        qp[pq[j]] = j;
    }

    /**
     * 删除队列中最小的值
     *
     * @return 最小值对应的索引
     */
    public int delMin() {
        // 获取最小元素关联的索引
        int minIndex = minIndex();

        // 交换 pq 中索引1处和最大索引处的值
        exch(1,n);

        // 删除 qp 中对应的值
        qp[pq[n]] = -1;

        // 删除 items 中对应的值
        items[pq[n]] = null;

        // 删除 pq 中最大索引处的新元素值
        pq[n] = -1;

        // 元素数量减 1
        n--;

        // 通过下沉调整 pq 堆
        sink(1);

        return minIndex;
    }

    /**
     * 向队列中插入一个元素t，对应索引i
     *
     * @param i
     * @param t
     */
    public void insert(int i, T t) {
        // 索引0处舍弃不用
        // 参数有效性检查 1 <= i < items.length
        if (i < 1 || i >= items.length) {
            return;
        }

        // 判断i是否已被关联，如果已被关联，则不允许插入
        if(contains(i)){
            return;
        }

        // 把数据存到 items 数组的 i 索引处
        items[i] = t;

        // 元素数量加 1
        n++;

        // 把 i 存到 pq 中
        pq[n] = i;

        // 用 qp 记录 pq 中的 i
        qp[i]=n;

        // 通过上浮调整 pq 堆
        swim(n);
    }

    /**
     * 上浮堆中索引k位置的元素，使处于合适的位置
     *
     * @param k
     */
    private void swim(int k) {
        // 循环比较索引k处元素和它父结点元素，如果父结点大，就交换位置
        while (k > 1) {
            // 比较当前结点与父结点
            if (less(k, k/2)) {
                // 父比子大，交换位置
                exch(k, k/2);
            }
            k = k / 2;
        }
    }

    /**
     * 下沉堆中索引k位置的元素，使处于合适的位置
     *
     * @param k
     */
    private void sink(int k) {
        // 循环比较当前结点k 和 min(左子结点2k，右子结点2k+1)的值，如果当前结点大，就交换位置

        // 循环条件 2*k <= n ：表示存在 左子结点
        while (2 * k <= n) {
            // 获取当前结点中的较小 子结点

            // 记录较小 子结点索引：默认为 左子结点
            int min = 2 * k;
            // 如果右结点存在，且左大于右，改变min
            if (2 * k + 1 <= n && less(2 * k +1, 2 * k)) {
                min = 2 * k + 1;
            }

            if (!less(min, k)) {
                // 当前结点不大于子结点，退出循环
                break;
            }

            // 当前结点大于子结点，交换位置
            exch(k, min);

            // 交换k值，继续循环
            k = min;
        }
    }

    /**
     * 判断k对应的元素是否存在
     *
     * @param k
     * @return
     */
    public boolean contains(int k) {
        return qp[k] != -1;
    }

    /**
     * 把索引i对应的元素修改为t
     *
     * @param i
     * @param t
     */
    public void changeItem(int i, T t) {
        // 修改 items 数组中索引 i 处的元素为 t
        items[i] = t;

        // 得到 items 中索引 i 在 pq 中的位置 k
        int k = qp[i];

        // 堆调整：修改后不确定是该下沉还是上浮，所以下沉和上浮都要做
        // 下沉
        sink(k);

        // 上浮：k处的元素和下沉时并不一定相同
        swim(k);
    }

    /**
     * 得到最小元素对应的索引
     *
     * @return
     */
    public int minIndex() {
        // pq是有序最小堆：1处最小
        return pq[1];
    }

    /**
     * 删除索引i对应的元素
     *
     * @param i
     */
    public void delete(int i) {
        // 得到 items 的索引 i 在 pq 中的位置
        int k = qp[i];
        // 交换 pq 中索引 k 处和最大处 n 的值
        exch(k,n);

        // 删除 qp 中相应的值
        qp[i] = -1;

        // 删除 items 中相应的值
        items[i] = null;

        // 删除 pq 中交换后的最大索引值（即原来k处的值）
        pq[n] = -1;

        // 元素数量减 1
        n--;

        // 调整堆：pq 中 k 处的新元素下沉
        // 只需下沉即可：因为 删除前 堆就是有序的，子结点大于父结点
        // 下沉后交换上来的结点，肯定也大于 k 的父结点，不需要上浮
        sink(k);

    }
}
