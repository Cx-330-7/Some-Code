package work.entity;

import lombok.Data;

@Data
public class LensAndRoads {
    private double[] len;
    private String[] road;
    public LensAndRoads(double[] len, String[] road){
        this.len = len;
        this.road = road;
    }
}
