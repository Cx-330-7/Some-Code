package work.entity;

import lombok.Data;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

@Data
public class EdgeWeightedDigraph {
    private int V;
    private int E;
    private Queue<Road>[] adj;

    public EdgeWeightedDigraph(int V) {
        this.V = V;
        this.E = 0;
        this.adj = new Queue[V];
        for (int i = 0; i < adj.length; i++) {
            adj[i] = new LinkedBlockingQueue<Road>();
        }
    }

    public void addEdge(Road road) {
        int scenicSpot = road.getStart();
        adj[scenicSpot].add(road);
        E++;
    }

    //获取加权有向边的所有边
    public Queue<Road> adj(int scenicSpot) {
        return adj[scenicSpot];
    }


    //获取加权有向边的所有边
    public Queue<Road> edges() {
        //创建一个队列，存储所有边
        Queue<Road> allRoad = new LinkedBlockingQueue<>();
        for (int v = 0; v < this.V; v++) {
            for (Road e : adj[v]) {
                allRoad.add(e);
            }
        }
        return allRoad;
    }
}
