package work.entity;

import lombok.Data;

/**
 * 边的实体类
 */
@Data
public class Road {
    private int start;//起点
    private int end;//终点
    private double length;//长度

    public Road(int start, int end, double length){
        this.start = start;
        this.end = end;
        this.length = length;
    }


}
