package work.entity;

import lombok.Data;

@Data
public class LenAndRoad {
    private double len;
    private String road;
    public LenAndRoad(double len,String road){
        this.len = len;
        this.road = road;
    }
}
