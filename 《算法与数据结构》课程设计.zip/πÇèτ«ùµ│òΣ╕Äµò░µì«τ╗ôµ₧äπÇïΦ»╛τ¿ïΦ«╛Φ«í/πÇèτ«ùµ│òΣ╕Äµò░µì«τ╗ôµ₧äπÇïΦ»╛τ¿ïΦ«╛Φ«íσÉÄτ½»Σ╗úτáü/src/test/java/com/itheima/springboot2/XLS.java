package com.itheima.springboot2;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class XLS {
    public static void main(String[] args) {
        try {
            //建立输入流
            FileInputStream fip = new FileInputStream("/Users/zhengjunyuan/Desktop/学员表.xls");
            HSSFWorkbook wb = new HSSFWorkbook(fip);
            Sheet sheet = wb.getSheet("学员表");
            Row row = sheet.getRow(0);
            String s1 = row.getCell(0).getStringCellValue();
            String s2 = row.getCell(1).getStringCellValue();
            System.out.println(s1+'\t'+s2);
            int n = sheet.getPhysicalNumberOfRows();
            for(int i = 1;i<n;i++){
                row = sheet.getRow(i);
                double a1 = row.getCell(0).getNumericCellValue();
                //
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


    }
}
