window.addEventListener('load', function () {
    const lis = this.document.querySelector('#daohang').querySelectorAll('li')
    const luru = this.document.querySelector('#luru')
    const chaxun = this.document.querySelector('#chaxun')
    const xiugai = this.document.querySelector('#xiugai')
    const shanchu = this.document.querySelector('#delete')
    // 导航栏功能
    for (let i = 0; i < lis.length; i++) {
        lis[i].addEventListener('click', function () {
            if (i === 0) {
                luru.style.display = 'block'
                chaxun.style.display = 'none'
                xiugai.style.display = 'none'
                shanchu.style.display = 'none'
            } else if (i === 1) {
                luru.style.display = 'none'
                chaxun.style.display = 'block'
                xiugai.style.display = 'none'
                shanchu.style.display = 'none'
            } else if (i === 2) {
                luru.style.display = 'none'
                chaxun.style.display = 'none'
                xiugai.style.display = 'block'
                shanchu.style.display = 'none'
            } else {
                luru.style.display = 'none'
                chaxun.style.display = 'none'
                xiugai.style.display = 'none'
                shanchu.style.display = 'block'
            }
        })
    }
    axios.defaults.baseURL = 'http://wd3zzr.natappfree.cc/api/idMag'
    // 录入部分
    const luru_name = this.document.querySelector('#luru_name')
    const luru_address = this.document.querySelector('#luru_address')
    const luru_phone = this.document.querySelector('#luru_phone')
    const luru_idCard = this.document.querySelector('#luru_idCard')
    const luru_submit = this.document.querySelector('#luru_submit')
    const luru_reset = this.document.querySelector('#luru_reset')
    // 重置功能
    luru_reset.addEventListener('click', function () {
        luru_name.value = ''
        luru_address.value = ''
        luru_phone.value = ''
        luru_idCard.value = ''
    })
    // 提交功能
    luru_submit.addEventListener('click', function () {
        // 表单预校验
        if (luru_name.value === '')
            alert('发送失败,请填写姓名')
        else if (luru_address.value === '')
            alert('发送失败,请填写地址')
        else if (luru_phone.value === '')
            alert('发送失败,请填写手机号')
        else if (luru_idCard.value === '')
            alert('发送失败,请填写身份证号')
        else {
            var name = luru_name.value
            var address = luru_address.value
            var idCard = luru_idCard.value
            var phone = luru_phone.value
            let data = {
                phone: phone,
                address: address,
                id: idCard,
                name: name
            }
            axios({
                method: 'POST',
                url: '/insert',
                data: data,
                transformRequest: [function (data) {
                    let ret = '';
                    for (let i in data) {
                        ret += encodeURIComponent(i) + '=' + encodeURIComponent(data[i]) + "&";
                    }
                    return ret;
                }],
                header: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }).then(res => {
                if (res.data.code === 200) {
                    alert('录入成功')
                    luru_reset.click()
                } else if (res.data.code === 999) {
                    alert('该身份证号已在系统中')
                }
            })
        }
    })
    //查询部分
    const chaxun_idCard = this.document.querySelector('#chaxun_idCard')
    const chaxun_name = this.document.querySelector('#chaxun_name')
    const chaxun_phone = this.document.querySelector('#chaxun_phone')
    const chaxun_address = this.document.querySelector('#chaxun_address')
    chaxun_idCard.addEventListener('blur', function () {
        if (chaxun_idCard.value === '') {
            chaxun_phone.innerHTML = ''
            chaxun_address.innerHTML = ''
            chaxun_name.innerHTML = ''
            return
        }
        var id = chaxun_idCard.value
        let data = {
            id: id
        }
        axios({
            method: 'POST',
            url: '/query',
            data: data,
            transformRequest: [function (data) {
                let ret = '';
                for (let i in data) {
                    ret += encodeURIComponent(i) + '=' + encodeURIComponent(data[i]) + "&";
                }
                return ret;
            }],
            header: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        }).then(res => {
            console.log(res);
            if (res.data.code === 200) {
                chaxun_name.innerHTML = '姓名:' + res.data.data.name
                chaxun_address.innerHTML = '地址:' + res.data.data.address
                chaxun_phone.innerHTML = '手机号:' + res.data.data.phone
            } else if (res.data.code === 999) {
                chaxun_phone.innerHTML = '查无此人'
                chaxun_address.innerHTML = ''
                chaxun_name.innerHTML = ''
            } else {
                chaxun_phone.innerHTML = '查询失败'
                chaxun_address.innerHTML = ''
                chaxun_name.innerHTML = ''
            }
        })
    })
    // 修改部分
    const xiugai_name = this.document.querySelector('#xiugai_name')
    const xiugai_address = this.document.querySelector('#xiugai_address')
    const xiugai_phone = this.document.querySelector('#xiugai_phone')
    const xiugai_idCard = this.document.querySelector('#xiugai_idCard')
    const xiugai_submit = this.document.querySelector('#xiugai_submit')
    const xiugai_reset = this.document.querySelector('#xiugai_reset')
    // 重置功能
    xiugai_reset.addEventListener('click', function () {
        xiugai_name.value = ''
        xiugai_address.value = ''
        xiugai_phone.value = ''
        xiugai_idCard.value = ''
    })
    // 修改功能
    xiugai_submit.addEventListener('click', function () {
        // 表单预校验
        if (xiugai_name.value === '')
            alert('发送失败,请填写姓名')
        else if (xiugai_address.value === '')
            alert('发送失败,请填写地址')
        else if (xiugai_phone.value === '')
            alert('发送失败,请填写手机号')
        else if (xiugai_idCard.value === '')
            alert('发送失败,请填写身份证号')
        else {
            var name = xiugai_name.value
            var address = xiugai_address.value
            var idCard = xiugai_idCard.value
            var phone = xiugai_phone.value
            let data = {
                phone: phone,
                address: address,
                id: idCard,
                name: name
            }
            axios({
                method: 'POST',
                url: '/change',
                data: data,
                transformRequest: [function (data) {
                    let ret = '';
                    for (let i in data) {
                        ret += encodeURIComponent(i) + '=' + encodeURIComponent(data[i]) + "&";
                    }
                    return ret;
                }],
                header: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }).then(res => {
                if (res.data.code === 200) {
                    alert('修改成功')
                    xiugai_reset.click()
                } else if (res.data.code === 999) {
                    alert('该身份证号未在系统中')
                }
            })
        }
    })
    // 删除部分
    const delete_idCard = this.document.querySelector('#delete_idCard')
    const delete_submit = this.document.querySelector('#delete_submit')
    delete_submit.addEventListener('click', function () {
        if (delete_idCard.value === '') {
            alert('请输入身份证号')
            return
        }
        var id = delete_idCard.value
        let data = {
            id: id
        }
        axios({
            method: 'POST',
            url: '/delete',
            data: data,
            transformRequest: [function (data) {
                let ret = '';
                for (let i in data) {
                    ret += encodeURIComponent(i) + '=' + encodeURIComponent(data[i]) + "&";
                }
                return ret;
            }],
            header: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        }).then(res => {
            if (res.data.code === 200) {
                alert('删除成功')
                delete_idCard.value = ''
            } else if (res.data.code === 999) {
                alert('该身份证号未在系统中')
            }
        })
    })
})