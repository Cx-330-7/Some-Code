window.addEventListener('load', function () {
    const btns = this.document.querySelectorAll('button')
    const rightMid_input = this.document.querySelector('#rightMid').querySelector('input')
    const Result = this.document.querySelector('#result')
    const rightDown_inputs = this.document.querySelector('#rightDown').querySelectorAll('input')
    axios.defaults.baseURL = 'http://i2pg37.natappfree.cc/api/guide'
    // 左侧简介信息显示
    for (let i = 0; i < btns.length; i++) {
        const element = btns[i];
        element.addEventListener('click', function () {
            axiosPost('POST', '/intro', {
                num: i + 1
            })
        })
    }
    // 右侧一点
    rightMid_input.addEventListener('blur', function () {
        axiosPost('POST', '/OneToAll', {
            point: this.value
        })
    })

    // 右侧两点
    rightDown_inputs[0].addEventListener('blur', function () {
        if (this.value === '' || rightDown_inputs[1].value === '')
            return
        axiosPost('POST', '/OneToOne', {
            start: this.value,
            end: rightDown_inputs[1].value
        })
    })
    rightDown_inputs[1].addEventListener('blur', function () {
        if (this.value === '' || rightDown_inputs[0].value === '')
            return
        axiosPost('POST', '/OneToOne', {
            start: rightDown_inputs[0].value,
            end: this.value
        })
    })
    //post请求函数封装
    function axiosPost(method, url, data) {
        let result = axios({
            method: method,
            url: url,
            data: data,
            transformRequest: [function (data) {
                let ret = '';
                for (let i in data) {
                    ret += encodeURIComponent(i) + '=' + encodeURIComponent(data[i]) + "&";
                }
                return ret;
            }],
            header: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        }).then(res => {
            Result.innerHTML = ''
            Result.style.padding = '10px'
            console.log(res.data.data);
            console.log(url);
            if (url === '/intro')
                Result.innerHTML = res.data.data
            else if (url === '/OneToAll') {
                console.log(res.data.code);
                if (res.data.code === 200) {
                    for (let i = 1; i < res.data.data.len.length; i++) {
                        const element = res.data.data.len[i];
                        const element2 = res.data.data.road[i]
                        if (element !== 0) {
                            Result.innerHTML = Result.innerHTML + '与' + i + '点地最短路径是:' + element
                            let br = document.createElement('br')
                            Result.appendChild(br)
                            Result.innerHTML = Result.innerHTML + element2
                            Result.appendChild(br)
                        }
                    }
                } else {
                    Result.innerHTML = '请输入正确的景点序号'
                }
            } else {
                console.log(res.data);
                if (res.data.code === 200) {
                    Result.innerHTML = Result.innerHTML + rightDown_inputs[0].value + '到' + rightDown_inputs[1].value + '的最短路径是:' + res.data.data.len
                    let br = document.createElement('br')
                    Result.appendChild(br)
                    Result.innerHTML = Result.innerHTML + res.data.data.road

                } else {
                    Result.innerHTML = '请输入正确的景点序号'
                }
            }
        }).catch(error => {
            return "exception=" + error
        });
        return result;
    }
})