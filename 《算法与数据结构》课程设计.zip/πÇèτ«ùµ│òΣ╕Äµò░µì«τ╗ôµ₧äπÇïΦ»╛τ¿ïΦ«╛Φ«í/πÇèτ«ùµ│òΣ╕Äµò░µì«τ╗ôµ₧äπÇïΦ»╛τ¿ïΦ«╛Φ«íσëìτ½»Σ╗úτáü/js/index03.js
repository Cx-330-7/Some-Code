window.addEventListener('load', function () {
    const btns = this.document.querySelectorAll('button')
    const times = this.document.querySelectorAll('#time')
    const Result = this.document.querySelector('#result')
    axios.defaults.baseURL = 'http://6hewvz.natappfree.cc/api/sort'
    var dict = {
        0: {
            name: '希尔排序',
            time: 0
        },
        1: {
            name: '冒泡排序',
            time: 0
        },
        2: {
            name: '快速排序',
            time: 0
        },
        3: {
            name: '插入排序',
            time: 0
        }
    }
    for (let i = 0; i < btns.length; i++) {
        const element = btns[i];
        element.addEventListener('click', function () {
            if (i === 0) {
                axiosPost('POST', '/shell', '', i)

            } else if (i === 1) {
                axiosPost('POST', '/bubble', '', i)

            } else if (i === 2) {
                axiosPost('POST', '/quick', '', i)

            } else {
                axiosPost('POST', '/insert', '', i)

            }
        })
    }

    //post请求函数封装
    function axiosPost(method, url, data, i) {
        let result = axios({
            method: method,
            url: url,
            data: data,
            transformRequest: [function (data) {
                let ret = '';
                for (let i in data) {
                    ret += encodeURIComponent(i) + '=' + encodeURIComponent(data[i]) + "&";
                }
                return ret;
            }],
            header: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        }).then(res => {
            // console.log(res.data.data);
            times[i].innerHTML = 'time:' + res.data.data + 'ms'
            dict[i].time = res.data.data
            console.log(dict[i].time)
            var sum = 0
            for (const key in dict) {
                if (dict[key].time > 0)
                    sum = sum + 1
            }
            if (sum === 4) {
                // 这里写排序代码
                var str = ''
                var a = 0
                var res = Object.keys(dict).sort(function (a, b) {
                    return dict[a].time - dict[b].time
                })
                console.log(res);
                for (const key in res) {
                    console.log(dict[res[key]].name);
                    if (a < 3)
                        str = str + dict[res[key]].name + '>'
                    else
                        str = str + dict[res[key]].name
                    a = a + 1
                }
                console.log(str);
                Result.innerHTML = str
            }

        }).catch(error => {
            return "exception=" + error
        });
        return result;
    }
})